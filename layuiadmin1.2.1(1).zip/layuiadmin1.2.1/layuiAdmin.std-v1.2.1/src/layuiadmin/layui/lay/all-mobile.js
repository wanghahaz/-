/**

 @Name：用于打包移动完整版
 @Author：贤心
 @License：LGPL
    
 */
 
layui.define(function(exports){
  exports('layui.mobile', layui.v);
});
